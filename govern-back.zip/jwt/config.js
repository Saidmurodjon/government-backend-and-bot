module.exports = {
  secretKey: "edu",
  expiresAt: 7200,
};
