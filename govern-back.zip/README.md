## Available Scripts

In the project directory, you can run:

- `npm start` or `node index.js`

Runs the app in the development mode.\
Open [http://localhost:5000](http://localhost:5000) to view it in your compyuter.\

- JWT olish uchun `POST` login `saidmurod` password `admin`

[http://localhost:5000/login](http://localhost:5000/login)

- Buyrtmachi ma'lumotari `GET` `UPDATE` `DELETE` `POST`

[http://localhost:5000/cilient](http://localhost:5000/cilient)

- Texnik hizmat ko'rsatish xodimi `GET` `UPDATE` `DELETE` `POST`

[http://localhost:5000/user](http://localhost:5000/user)

- Bajarilgan ishlar `GET` `UPDATE` `DELETE` `POST`

[http://localhost:5000/report](http://localhost:5000/report)

- Hokimyatdagi bo'limlar `GET` `UPDATE` `DELETE` `POST`

[http://localhost:5000/bolim](http://localhost:5000/bolim)

- Hokimyatdagi lavozimlar `GET` `UPDATE` `DELETE` `POST`

[http://localhost:5000/lavozim](http://localhost:5000/lavozim)

- Hisobot o'zgaruvchan qismi ma'lumotlari `GET` `UPDATE`

[http://localhost:5000/xisobot](http://localhost:5000/xisobot)

- Tashkilot ma'lumotlari `GET` `UPDATE` `DELETE` `POST`

[http://localhost:5000/tashkilot](http://localhost:5000/tashkilot)

- Texnik hizmat turlari `GET` `UPDATE` `DELETE` `POST`

[http://localhost:5000/ish](http://localhost:5000/ish)

- Hokimyatdagi qurilmalar `GET` `UPDATE` `DELETE` `POST`

[http://localhost:5000/device](http://localhost:5000/device)

- Hokimyatdagi qurilmalar tarkibi `GET` `UPDATE` `DELETE` `POST` Device \_id bo'yicha

[http://localhost:5000//device/elem](http://localhost:5000/device/elem)
